# IBS M1 – Static App

This repo hosts a single-file static app (`index.html`).

## Quick publish on GitHub Pages
1) Create a new repo and upload all files in this folder (index.html and .nojekyll).
2) Go to **Settings → Pages**.
3) Under **Build and deployment**, choose **Deploy from a branch**.
4) Select **Branch: main** and **Folder: / (root)**, then **Save**.
5) Wait for the green banner with the published URL.

> Canvas LMS: add this URL as a **Module → External URL** (Load in a new tab).